let a=chrome.devtools.network.getHAR();
console.log(a);
console.log("dev tools run")